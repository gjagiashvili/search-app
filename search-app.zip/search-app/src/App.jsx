import React, { useState } from 'react'
import MainNote from './components/MainNote'
import './App.css'

function App() {
  

  return (
    <>
      <MainNote />
    </>
  )
}

export default App
